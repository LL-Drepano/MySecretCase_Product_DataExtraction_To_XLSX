# Pack Dieline Data Extraction → Google Sheets

An automated pipeline that extracts structured product data from packaging dieline PDFs and maps it to a spreadsheet with **one row per pack and one column per field**, following the supplied 34-column reference mapping.

## Results

- **Reference set:** 34/34 columns resolved for 4/4 test packs, with 0 failed packs.
- **Full batch:** all 50 packs processed through the automated batch runner.
- **Manual validation:** a stratified sample of 15 rows was reviewed — 5 High, 5 Medium, and 5 Low confidence.
- **Observed accuracy on the reviewed sample:** **100%**, with 0 extraction errors and 0 complete failures.

Cases marked `NEEDS_REVIEW`, such as missing or unreadable LOT or product dimensions, were verified to reflect information genuinely absent or unreadable in the source PDF rather than model hallucinations.

For long runs, `batch_run.py` automatically splits the input into groups of 5 PDFs, pauses between groups, retries temporary API failures, and merges all partial workbooks into one final Excel file. The operator still uses a single input folder and a single command.

---

## 1. Why the architecture is hybrid

A conventional `pdfplumber → columns` pipeline is not sufficient for these files because most of the visible text has been converted to vector outlines, as is common in print-production artwork.

Diagnostics on the four reference files:

| Check | Result |
|---|---|
| Embedded fonts | Only 2 residual fonts: FlamaCondensed and Figtree |
| Extractable text with `pdftotext` | Only 22 characters in total: `FR 21 7 PAP CPE` |
| Vector objects per page | Approximately 1,950 |
| Raster images | 0 — barcodes and QR codes are also vector graphics |

Product name, dimensions, LOT, battery specifications, material, warranty information, and most icons therefore do not exist as extractable text. They exist as graphics.

The solution combines:

- deterministic extraction for reliable anchors;
- PDF rasterization;
- a multimodal LLM for semantic fields and icons;
- validation rules, confidence scoring, and review flags.

## 2. Architecture

```text
                    Dieline PDF
                         │
      ┌──────────────────┼─────────────────────┐
      │ DETERMINISTIC    │ VISION LLM          │
      ▼                  ▼                     ▼
  filename parsing   live PDF text        page 1 raster
  EAN-13 +           "FR 21 7 PAP CPE"    → Gemini, temp 0,
  box dimensions     → PAP21 / CPE07         response schema,
  product name                              double reading
  brand constants                         → LOT, battery, IPX,
                                         dimensions, features,
                                         symbols and icons
      │                  │                     │
      └──────────────────┴──────────┬──────────┘
                                   ▼
                           VALIDATION GUARDS
                  EAN check digit · double-read agreement
                    domain rules · missing-field handling
                                   ▼
                     34 mapped columns + provenance
                    + confidence + flags → spreadsheet
```

Field provenance is visible in the spreadsheet header:

- **green:** deterministic source;
- **blue:** vision model;
- **red:** external source required.

For larger volumes, `batch_run.py` wraps the core CLI. It creates temporary groups of 5 PDFs, invokes `run.py` for each group, applies pauses and batch-level retries, and merges the partial workbooks without changing the extraction logic or the 34-column schema.

## 3. Technology stack

| Layer | Tool | Purpose |
|---|---|---|
| PDF parsing | `pdfplumber`, `pypdf` | Extract residual live text and coordinates |
| Rasterization | Poppler: `pdftoppm` | Convert page 1 to JPEG for vision processing |
| Image processing | `Pillow` | Cropping and upscaling for targeted re-reads |
| Vision model | Gemini Flash, configurable with `--model` | Semantic fields, symbols, icons, structured JSON output |
| HTTP client | `requests` | Direct REST calls, temperature 0, retries and backoff |
| Local orchestration | `batch_run.py` | Groups of 5, pauses, batch retries and workbook merge |
| Spreadsheet output | `openpyxl` | Write and consolidate `.xlsx` files compatible with Google Sheets |
| Possible cloud evolution | `n8n` + `gspread` | Drive trigger and direct append to Google Sheets |
| Optional validation | `pyzbar` | Third EAN cross-check by decoding the barcode |

The model is called directly through REST so that the pipeline can enforce:

- `temperature = 0` for repeatability;
- a response schema for structured JSON;
- two independent reads of each pack.

## 4. End-to-end process

1. **Parse the filename**  
   A regex extracts EAN-13, external box dimensions in millimetres, and product name or variant from the `EAN_LxWxH_Name` pattern.

2. **Validate the EAN**  
   The EAN-13 check digit is verified deterministically.

3. **Extract residual live text**  
   `pdfplumber` reads the remaining recycling string, such as `FR 21 7 PAP CPE`. Spatial pairing maps it to `PAP21` for the box and `CPE07` for the bag.

4. **Add brand constants**  
   Manufacturer and importer data, which are shared across MySecretCase products, are populated deterministically.

5. **Rasterize page 1**  
   `pdftoppm` renders the first PDF page at 200 DPI.

6. **Run vision extraction**  
   Gemini returns schema-conformant JSON for LOT, battery, charging method, IP rating, material, product dimensions, feature counts, symbols, QR codes, and other visual fields.

7. **Double-read validation**  
   Each image is read twice at temperature 0. Disagreements are not silently accepted as reliable values.

8. **Apply validation guards**  
   Domain rules assign confidence and flags.

9. **Process the full folder in batches**  
   `batch_run.py` automatically divides the folder into groups of 5 PDFs, invokes `run.py`, waits 60 seconds between groups, and retries a failed group up to 4 times with a 120-second delay.

10. **Merge partial outputs**  
    Intermediate workbooks are merged into one `.xlsx` file while preserving the 34 official columns and the helper columns for EAN, box dimensions, confidence, flags, and product name.

11. **Open in Google Sheets**  
    The final Excel file can be uploaded to Google Drive and opened with Google Sheets.

## 5. Error handling

The system does not invent missing information. Unreadable or absent values are explicitly flagged.

| Situation | Behaviour |
|---|---|
| Invalid EAN-13 check digit | Flag + **Low** confidence |
| Missing LOT or product dimensions | `❌` + `NEEDS_REVIEW` + **Low** confidence |
| Vision double-read disagreement | Conflicting field is cleared and flagged; **Medium** confidence |
| Waterproof claim without an IP code on an electronic product | Domain-rule flag; **Medium** confidence |
| Feature visible on the pack but absent from the required mapping | Handled according to the agreed mapping rules |
| Low-resolution field | Targeted crop, upscale, and re-read |
| API response `429`, `500`, or `503` | Per-request retry with exponential backoff: 1, 2, 4, and 8 seconds |
| Request retries exhausted during a long run | Automatic groups of 5, a 60-second inter-batch pause, and up to 4 retries of the full group with a 120-second delay |
| Non-conforming filename | Row is retained with an empty EAN and an explanatory flag |

The final workbook includes **Confidence** and **Flags / Notes** helper columns, allowing a reviewer to focus only on non-High-confidence rows.

Intermediate workbooks are stored under `output/_batch_files` during execution and automatically consolidated into the final output.

## 6. Accuracy evaluation

### Initial reference validation

| Pack | Result |
|---|---|
| Coniglietto Schizzetto | 34/34, High confidence |
| Clitofono | 34/34, High confidence |
| Confetto Pornetto | 34/34, High confidence; Sexy Ideas correctly absent |
| Godolo | 34/34, correctly flagged: non-electronic product fields set to `❌`; waterproof wording captured without inventing an IP code |

Reference-set result: **3 High-confidence perfect rows, 1 correctly flagged row, 0 failures**.

### Full-batch validation

The full set of 50 packs was processed using the automatic batch runner.

A stratified manual review was carried out on 15 rows:

- 5 High-confidence rows;
- 5 Medium-confidence rows;
- 5 Low-confidence rows.

All reviewed values matched the information present in the corresponding dielines:

- **observed field accuracy on the reviewed sample:** 100%;
- **extraction errors found:** 0;
- **complete failures found:** 0;
- **false-positive review flags found:** 0.

Rows marked `NEEDS_REVIEW` were checked and found to represent genuinely missing or unreadable source information. The flag therefore behaved as intended: it prevented unsupported values from being generated and directed human review to the correct cases.

The reported 100% is an observed result on the stratified 15-row sample, not a claim of cell-by-cell manual validation across all 50 rows.

## 7. Estimated cost per pack

- **Deterministic processing:** approximately €0.
- **Vision processing:** one rasterized image per pack, read twice for validation.
- **Estimated production cost with a Flash-class model:** approximately **€0.002–€0.005 per pack**, including a retry allowance.
- **Free tier during testing:** €0 direct API cost.

For 50 packs, the total model cost is expected to remain in the order of cents. The practical constraint is API rate limiting rather than model cost.

For commercial production, a paid Gemini API project or Vertex AI deployment is preferable because quotas and data-use terms differ from the free tier.

## 8. Processing time

| Stage | Indicative time |
|---|---|
| Filename, EAN, and residual text parsing | Milliseconds |
| Page 1 rasterization | Approximately 0.4 seconds per pack |
| Vision calls, two reads | Approximately 2–5 seconds per pack |
| Throttling pause | 60 seconds between consecutive groups |
| Failed-group retry | 120-second delay, up to 4 attempts |

The operational configuration uses **N = 5 packs per group**.

For 50 packs:

- 10 groups are created;
- 9 intentional pauses are applied;
- throttling accounts for approximately 9 minutes;
- expected total time without retries is approximately **11–14 minutes**.

Actual execution time depends on API latency and the quota assigned to the selected model.

```text
total time ≈ pack processing time
           + (number of groups - 1) × pause
           + retry time, if any
```

## 9. Limitations and possible improvements

- **API rate limits:** batching makes the free-tier workflow reliable but increases total runtime. A paid quota, adaptive rate limiter, or persistent queue could improve throughput.
- **ASIN is not printed on the pack:** it requires an external catalogue or PIM source joined by EAN. The current value is `N/D`.
- **Third EAN cross-check:** enable `pyzbar` to compare the decoded barcode with the filename EAN and the printed digits.
- **Layout drift detection:** flag dielines with unexpected fonts, missing icon grids, or structural changes before trusting the output.
- **OCR fallback:** use Tesseract for a limited set of text-only fields when the vision service is unavailable.
- **Direct Google Sheets output:** replace the intermediate `.xlsx` with `gspread` and a service account.
- **Human-review queue:** automatically place non-High-confidence rows in a dedicated `Needs review` tab.
- **Resume support:** persist completed groups so a restarted run continues from the last successful group.
- **Adaptive batching:** adjust group size and pause duration dynamically based on API responses.

## 10. Running the project

### Requirements

- Python 3.10 or newer;
- Poppler available on the system path;
- a Gemini API key;
- a Flash model ID available to the account.

Install Python dependencies:

```bash
pip install -r requirements.txt
```

Verify Poppler:

```bash
pdftoppm -v
```

### Full run — Windows PowerShell

```powershell
$env:GEMINI_API_KEY="..."
$env:MODEL="<available-flash-model-id>"

python batch_run.py .\fustelle `
  --model $env:MODEL `
  --out output\Dati_Pack.xlsx `
  --batch-size 5 `
  --pause 60 `
  --retries 4 `
  --retry-wait 120
```

The operational values above are also the defaults, so the command can be shortened to:

```powershell
python batch_run.py .\fustelle --model $env:MODEL --out output\Dati_Pack.xlsx
```

### Full run — macOS or Linux

```bash
export GEMINI_API_KEY="..."
export MODEL="<available-flash-model-id>"

python batch_run.py ./fustelle \
  --model "$MODEL" \
  --out output/Dati_Pack.xlsx \
  --batch-size 5 \
  --pause 60 \
  --retries 4 \
  --retry-wait 120
```

### Small-folder or single-batch run

```bash
python run.py ./fustelle --model "$MODEL" --out output/Dati_Pack.xlsx
```

### Validate against the four reference packs

```bash
python validate.py ./test --model "$MODEL"
```

At the end of each `run.py` execution, the CLI prints:

- number of processed packs;
- High, Medium, and Low confidence counts;
- the list of flagged rows.

## 11. Mapping decisions

The **34 official columns** reproduce the supplied reference mapping in the same order. The required structure is not modified.

The grey helper columns on the right are operational metadata and may be removed before delivery:

- `EAN (reference)`;
- `Box dimensions (reference)`;
- `Confidence`;
- `Flags / Notes`;
- `Product (reference)`.

Decisions applied:

1. **EAN** is retained as a grey reference column used to identify the row. It is not substituted for `Type or model`, which remains `N/A` as in the reference.
2. **ASIN** is not printed on the pack and is therefore set to `N/D`; populating it requires an external EAN-to-ASIN source.
3. **Sexy Ideas** is mapped as presence only: `✅` or `❌`.
4. **Remote-controlled** may be visible on some packs but is not part of the supplied mapping, so it is ignored according to the agreed mapping rules.

## Repository structure

```text
task2-fustelle-extraction/
├── README.md              project overview and required documentation
├── RUNBOOK.md             operational instructions
├── requirements.txt       Python dependencies
├── gemini_vision.py       Gemini REST extractor, schema, retries and double read
├── extract_pack.py        filename parsing, PDF processing, guards and workbook writing
├── validate.py            live validation against the four reference fixtures
├── run.py                 core CLI: one folder → one workbook
├── batch_run.py           groups of 5, pauses, retries and automatic workbook merge
└── output/                generated locally; not required in source control
```

## Security and repository hygiene

Do not commit:

- `GEMINI_API_KEY` or any other credentials;
- the `.venv` directory;
- source PDFs supplied by the company;
- generated workbooks containing company or product data;
- temporary batch directories.

The included `.gitignore` excludes these items by default.
